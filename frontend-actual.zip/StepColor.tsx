'use client'

import type { Color } from '@/types'
import ProbadorVisual from './ProbadorVisual'

interface StepColorProps {
  colores: Color[]
  coloresFiltrados: Color[]
  seleccionado: Color | null
  onSelect: (color: Color) => void
  tipoNombre: string
  telaNombre: string
}

export default function StepColor({
  colores,
  coloresFiltrados,
  seleccionado,
  onSelect,
  tipoNombre,
  telaNombre,
}: StepColorProps) {
  const lista = coloresFiltrados.length > 0 ? coloresFiltrados : colores

  return (
    <div className="flex flex-col gap-6">
      {/* Selector de colores */}
      <div>
        <p style={{ color: 'var(--text-muted)', fontSize: 13, marginBottom: 14 }}>
          Elegí el color de tu cortina
        </p>
        <div className="flex flex-wrap gap-3">
          {lista.map(color => {
            const isSelected = seleccionado?.id === color.id
            return (
              <button
                key={color.id}
                onClick={() => onSelect(color)}
                title={color.nombre}
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  gap: 6,
                  background: 'none',
                  border: 'none',
                  cursor: 'pointer',
                  padding: 0,
                }}
              >
                <div
                  style={{
                    width: 44,
                    height: 44,
                    borderRadius: '50%',
                    background: color.hex,
                    border: isSelected
                      ? '3px solid var(--gold)'
                      : '2px solid var(--border)',
                    boxShadow: isSelected ? '0 0 0 2px var(--gold-border)' : 'none',
                    transition: 'border 0.15s, box-shadow 0.15s',
                    flexShrink: 0,
                  }}
                />
                <span
                  style={{
                    color: isSelected ? 'var(--gold)' : 'var(--text-muted)',
                    fontSize: 11,
                    maxWidth: 52,
                    textAlign: 'center',
                    lineHeight: 1.3,
                    transition: 'color 0.15s',
                  }}
                >
                  {color.nombre}
                </span>
              </button>
            )
          })}
        </div>
      </div>

      {/* Probador visual o placeholder */}
      {seleccionado ? (
        <ProbadorVisual
          colorHex={seleccionado.hex}
          tipoNombre={tipoNombre}
          telaNombre={telaNombre}
        />
      ) : (
        <div
          style={{
            background: 'var(--surface)',
            border: '1px solid var(--border)',
            borderRadius: 'var(--radius)',
            padding: '32px 24px',
            textAlign: 'center',
          }}
        >
          <p style={{ color: 'var(--gold)', fontSize: 13, fontWeight: 600, marginBottom: 8 }}>
            ✦ Probador visual
          </p>
          <p style={{ color: 'var(--text-muted)', fontSize: 13 }}>
            Seleccioná un color para visualizarlo en tu habitación
          </p>
        </div>
      )}
    </div>
  )
}